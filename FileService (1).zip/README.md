
  # FileService

  This is a code bundle for FileService. The original project is available at https://www.figma.com/design/FdePJFrEYzGbfu4hl0q6qb/FileService.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  