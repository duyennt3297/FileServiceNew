# Documentation

This folder contains documentation for the Couppa video management system.

## Structure

- `/database` - Database schema, ERD, and data models documentation
