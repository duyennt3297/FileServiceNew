import { useState } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { FileManager } from './components/FileManager';
import { FileUpload } from './components/FileUpload';
import { StorageStats } from './components/StorageStats';
import { ArticlesList } from './components/ArticlesList';
import { ArticleEditor, ArticleFormData } from './components/ArticleEditor';
import { toast } from 'sonner';
import { Toaster } from './components/ui/sonner';

interface UploadedFile {
  file: File;
  preview?: string;
  progress: number;
  status: 'pending' | 'uploading' | 'success' | 'error';
}

export default function App() {
  const [activeMenu, setActiveMenu] = useState('files');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [editingArticleId, setEditingArticleId] = useState<string | null>(null);

  const handleFileUpload = (files: UploadedFile[]) => {
    console.log('Uploading files:', files);
    
    toast.success('Files uploaded successfully', {
      description: `${files.length} file(s) have been uploaded to your storage.`,
    });
    
    setShowUploadModal(false);
  };

  const handleOpenUploadModal = () => {
    console.log('Event: open_file_upload');
    setShowUploadModal(true);
  };

  const handleCloseUploadModal = () => {
    setShowUploadModal(false);
  };

  const handleCreateFolder = () => {
    console.log('Event: create_folder');
    toast.info('Create Folder', {
      description: 'Folder creation feature coming soon!',
    });
  };

  const handleArticleSave = (article: ArticleFormData) => {
    console.log('Saving article:', article);
    
    const statusMessage = article.status === 'PUBLISHED' 
      ? 'Article published successfully!'
      : 'Article saved as draft';
    
    toast.success(statusMessage, {
      description: article.status === 'PUBLISHED' 
        ? 'Your article is now live and visible to readers.'
        : 'You can continue editing and publish later.',
    });
    
    setActiveMenu('articles-list');
    setEditingArticleId(null);
  };

  const handleEditArticle = (articleId: string) => {
    setEditingArticleId(articleId);
    setActiveMenu('articles-create');
  };

  const handleCreateArticle = () => {
    setEditingArticleId(null);
    setActiveMenu('articles-create');
  };

  const handleBackToList = () => {
    setEditingArticleId(null);
    setActiveMenu('articles-list');
  };

  return (
    <div className="flex h-screen bg-background">
      <Toaster position="top-right" />
      <Sidebar activeMenu={activeMenu} onMenuClick={setActiveMenu} />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto">
          {/* Page Content */}
          <div className="p-6">
            {activeMenu === 'files' && (
              <FileManager 
                onUploadClick={handleOpenUploadModal}
                onCreateFolderClick={handleCreateFolder}
              />
            )}
            {activeMenu === 'storage' && (
              <StorageStats />
            )}
            {activeMenu === 'folders' && (
              <div className="bg-white rounded-lg p-8 text-center text-gray-500">
                Folder management coming soon...
              </div>
            )}
            {activeMenu === 'articles-list' && (
              <ArticlesList 
                onCreateClick={handleCreateArticle}
                onEditClick={handleEditArticle}
              />
            )}
            {activeMenu === 'articles-create' && (
              <ArticleEditor 
                articleId={editingArticleId || undefined}
                onBack={handleBackToList}
                onSave={handleArticleSave}
              />
            )}
            {activeMenu === 'dashboard' && (
              <div className="bg-white rounded-lg p-8 text-center text-gray-500">
                Dashboard coming soon...
              </div>
            )}
            {!['files', 'storage', 'folders', 'articles-list', 'articles-create', 'dashboard'].includes(activeMenu) && (
              <div className="bg-white rounded-lg p-8 text-center text-gray-500">
                {activeMenu.charAt(0).toUpperCase() + activeMenu.slice(1)} section
              </div>
            )}
          </div>
        </main>
      </div>

      {/* File Upload Modal */}
      <FileUpload
        isOpen={showUploadModal}
        onClose={handleCloseUploadModal}
        onSubmit={handleFileUpload}
      />
    </div>
  );
}